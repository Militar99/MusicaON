const itens = //Cuidado com as virgulas!!!!!!!!!
[
    {
        nome: "gaita",
        tipo: "sopro"
    },
    {
        nome: "flauta",
        tipo: "sopro"
    },
    {
        nome: "saxofone",
        tipo: "sopro"
    },
    {
        nome: "guitarra",
        tipo: "corda"
    },
    {
        nome: "violino",
        tipo: "corda"
    },

    {
        nome: "cavaco",
        tipo: "corda"
    },

    {
        nome: "pandero",
        tipo: "percussão"
    },

    {
        nome: "teclado",
        tipo: "percussão"
    },

    {
        nome: "sanfona",
        tipo: "percussão"
    },

    
];

//Passaremos as informações como string



const lista = document.getElementById("lista");
const data = document.getElementById("data");
 
lista.style.fontFamily = "Comic Sans MS";
 
function search() {
    lista.innerHTML = "";
    for (let i = 0; i <= itens.length - 1; i++) {
         
        
        let pattern = new RegExp(data.value.toLowerCase(), 'g');
        if(itens[i].tipo.toLowerCase().match(pattern)) {
            lista.innerHTML += 
            `
            <li>
                <h5>  ${itens[i].nome} </h5>  
            </li>
            
            `;
        }
    }
}

