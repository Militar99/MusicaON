function Enviar(){
    let Nome=document.getElementById("Nome");
    let Idade=document.getElementById("Idade");
    let Email=document.getElementById("Email");
    let Telefone=document.getElementById("Telefone");
    let Mensagem=document.getElementById("Mensagem");
    let Termos=document.getElementById("Termos");
 

    if(Nome.value .length == 0){
    Mensagem.innerHTML=('por favor, preencha o Nome')}

    else if(Email.value .length <=9){
    Mensagem.innerHTML=('por favor, preencha o Email corretamente')}

    else if(Idade.value .length == 0){
    Mensagem.innerHTML=('por favor, preencha sua idade corretamente')}

    else if(Telefone.value . length != 14){
    Mensagem.innerHTML=('por favor, preencha o Telefone corretamente')}

    else if(Termos.checked == false ){
    Mensagem.innerHTML=('por favor, aceite os termos e acordos')}

    else{
    Mensagem.innerHTML= ('Parabéns ' +  Nome.value + ', seu cadastro foi feito com sucesso!!');
    }
}